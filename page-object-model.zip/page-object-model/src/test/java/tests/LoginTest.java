package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.IndexPage;
import pages.LoginPage;
import utils.TestUtils;

public class LoginTest extends BaseClass{
	
	WebDriver driver;
	@BeforeClass
	public void setup() {
		driver = chromeSetup("https://www.npntraining.com/automation_projects/hotel_management_system/login.php");
	}
	@Test
	public void login() {
		LoginPage loginPage = new LoginPage(driver);
		IndexPage indexPage = loginPage.login("admin", "admin");
		new TestUtils();
		String indexUrl = TestUtils.getCurrentAppUrl(driver);
		Assert.assertTrue(indexUrl.contains("dashboard"));
		indexPage.signout();
	}
	
	@AfterClass
	public void tearDown() {
		tearDown(driver);
	}

}
