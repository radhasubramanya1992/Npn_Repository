package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	WebDriver driver;
	WebElement userNameTxt;
	WebElement passwordTxt;
	WebElement loginBtn;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		this.userNameTxt = driver.findElement(By.name("email"));
		this.passwordTxt = driver.findElement(By.name("password"));
		this.loginBtn = driver.findElement(By.name("login"));
	}
	
	public IndexPage login(String userName, String password) {
		userNameTxt.sendKeys(userName);
		passwordTxt.sendKeys(password);
		loginBtn.click();
		return new IndexPage(driver);
	}
	

}
