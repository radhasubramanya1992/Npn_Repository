package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utils.TestUtils;

public class IndexPage {
	
	WebDriver driver;
	WebElement dashBoardLeftMenuItem;
	WebElement reservationLeftMenuItem;
	WebElement manageRoomsLeftMenuItem;
	WebElement staffSectionLeftMenuItem;
	WebElement manageCompliantsLeftMenuItem;
	WebElement knowMoreLeftMenuItem;
	WebElement avatar;
	WebElement signOutBtn;


	
	public IndexPage(WebDriver driver){
		this.driver = driver;
		this.dashBoardLeftMenuItem = driver.findElement(By.xpath("//a[contains(text(), 'Dashboard')]"));
		this.reservationLeftMenuItem = driver.findElement(By.xpath("//a[contains(text(), 'Reservation')]"));
		this.manageRoomsLeftMenuItem = driver.findElement(By.xpath("//a[contains(text(), 'Manage Rooms')]"));
		this.staffSectionLeftMenuItem = driver.findElement(By.xpath("//a[contains(text(), 'Staff Section')]"));
		this.avatar = driver.findElement(By.cssSelector(".navbar-header a[data-toggle=\"dropdown\"]"));
		this.signOutBtn = driver.findElement(By.cssSelector("a[href='logout.php']"));
	}
	
	
	
	public void signout() {
		avatar.click();
		signOutBtn.click();
		
	}
	
	public void selectRoomType() {
		TestUtils.selectFromDropDown(driver, signOutBtn, "value");
	}

}
